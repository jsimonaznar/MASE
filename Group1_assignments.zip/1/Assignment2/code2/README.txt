<^> CODE INSTRUCTIONS <^>
By: Jorge Simón, javier Sanchez & Iñaki Fernandez

In this directory you can find one code:

1- main.py which is the main program

Outputs:
- validation.txt contains the results for both methods using arbitrary values of M and e. Also shows the required iterations that each method needs to converge.

- NR_eccentricity.pdf & SM_eccentricity.pdf contains the results for different values of e for a range of M=[0,2\pi].

- NR_iterationMap.pdf and SM_iterationMap.pdf contains iterations required for each method to converge for a range of M=[0,2\pi] and e=[0,1]. Here one can encounter some problems at the poles of the ranges. The discussion around this ranges can be found in the report.

Initial guesses:

- The initial guess for N-R method can be found in line 69.
- The initial guess for SM method can be found in line 100. 

The code only uses one external module which is numpy. It can be installed using:
>>pip install numpy

The main code can be executed using:
>>python3 main.py

If there is any problem in the executation please write to:
inakiphy@gmail.com


