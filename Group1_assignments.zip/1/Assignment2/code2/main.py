#=======================================
#
# Kepler Equation solver using:
#  1-Newton-Rhapson Method.
#  2-Secant Mehotd
# 
# Master in Space and Aeronautical
# Engineerign.
# Astrodynamics Course, Assignment 2.
# By: Jorge Simón Javier Sanchez
# & Iñaki Fernandez.
# Last modification: 1/11/2023
#
#=======================================

#=======================================
# Import Modules
#=======================================

import numpy as np
import matplotlib.pyplot as plt

#=======================================
# Define function and derivative.
#=======================================

def kepler_eq(M, E, e):
    #===================================
    # We define the Kepler Equation
    # M is the mean anomaly.
    # e is the eccentricity.
    # E is the aimed solution.
    #===================================
    return E - e * np.sin(E) - M

def kepler_eq_dev(M, E, e):
    #===================================
    # We define the Kepler Equation 
    # derivative.
    # E is the aimed solution.
    #===================================
    return 1.0 - e * np.cos(E)

#=======================================
# Newton-Raphson Method
#=======================================

def newton_rhapson_method(M,e,N,eps):
    #===================================
    # M is the mean anomaly.
    # e is the esccentricity.
    # N is the iteration steps
    # for N-R method.
    # eps is the accuracy of the method
    #
    # The algorithm:
    #
    # x1 = x0 - f(x0) / f'(x0)
    # Is |x1-x0| < eps?
    # YES: root x1
    # NO : x0 = x1 and repeat.
    #
    # Our functions:
    # f(E) = E - e * sin(E) - M
    # f'(E) = 1 - e * cos(E)
    #===================================

    # Initial guess
    x0 = M                               # Initial guess [M, pi, M + e*cos(M)].

    # Iterations for the N-R method
    for i in range(N):

        x1 = x0 - (kepler_eq(M,x0,e)) / (kepler_eq_dev(M,x0,e))

        # if for accuracy
        if np.abs(x1 - x0) < eps:
            return x1,i
            break
        else:
            x0 = x1
    print("=====================================")
    print("<^> WARNING: N-R DID NOT CONVERGE <^>")
    print("=====================================")

#=======================================
# Secant Method.
#=======================================
def secant_method(M, e, N, eps):
    #===================================
    # Secant method: ( stimation of the
    # derivative.
    # The algorithm:
    # 
    # x2 = x1 - (x1-x0) / (f(x1) - f(x0)) * f(x1)
    # Is |x2-x1| < eps?
    # YES: root x2
    # NO : x0 = x1 x1 = x2 and repeat.
    #===================================
    x0 = M                               # Initial guess [M, pi, M + e*cos(M)].
    x1 = M + 0.1                         # Good initial guess.
    for i in range (N):
        f0 = kepler_eq(M, x0, e)
        f1 = kepler_eq(M, x1, e)
        x2 = x1 - (x1 - x0) / (f1 - f0) * f1

        if np.abs(x2 - x1) < eps:
            return x2,i
            break
        else:
            x0, x1 = x1, x2

    print("===============================================")
    print("<^> WARNING: SECANT METHOD DID NOT CONVERGE <^>")
    print("===============================================")


#=======================================
# MAIN PROGRAM!!!!!!!!!!!!!!!!!!!!!!!!!!
#=======================================
print("=================================================")
print("Starting validation calculations, it might take a few seconds :)")
print("Initial guess for N-R can be found in line 69")
print("Initial guess for SM can be found in line 100")
print("By:Jorge Simón, Javier Sanchez & Iñaki Fernandez.")
print("=================================================")


#=======================================
# Validation 1.
#=======================================

# Comparison between both methods

M = 0.5                                  # Mean anomaly (will be given)
e = 0.2                                  # Eccentricity (will be given)
N = 100000000                            # N-R Max iteration. INTEGER!
eps = 10E-015                            # N-R accuracy

root1 = newton_rhapson_method(M,e,N,eps)
root2 = secant_method(M, e, N, eps)

# Store validation values in output_file
output_file = "validation.txt"
with open(output_file, "w") as file:
    file.write("=======================================================\n")
    file.write("Kepler equation solver.\n")
    file.write("Master in Space and Aeronautical Engineerign.\n")
    file.write("Astrodynamics Course, Assginment 2.\n")
    file.write("By: Jorge Simón, Javier Sanchez & Iñaki Fernandez.\n")
    file.write("============================" + "\n" + "Newton-Raphson Method Solver" + "\n" + "Eccentric Anomaly E and required iterarions: " + str(root1) + "\n")
    file.write("============================" + "\n" + "Secant Method Solver" + "\n" + "Eccentric Anomaly E and required iterarions: " + str(root2) + "\n")

#=======================================
# Validation 2.
#=======================================

# Comparison plot for different eccentricity

N        = 100000000                           # N-R Max iteration. INTEGER!
eps      = 10E-015                             # N-R accuracy
W        = 1000                                # Solution points quantity

E1_NR    = np.zeros(W)                         # Roots matrix for e1
E2_NR    = np.zeros(W)                         # Roots matrix for e2
E3_NR    = np.zeros(W)                         # Roots matrix for e3
E4_NR    = np.zeros(W)                         # Roots matrix for e4
E5_NR    = np.zeros(W)                         # Roots matrix for e5
E1_SM    = np.zeros(W)                         # Roots matrix for e1
E2_SM    = np.zeros(W)                         # Roots matrix for e2
E3_SM    = np.zeros(W)                         # Roots matrix for e3
E4_SM    = np.zeros(W)                         # Roots matrix for e4
E5_SM    = np.zeros(W)                         # Roots matrix for e5
e1       = 0.1                                 # e1
e2       = 0.3                                 # e2
e3       = 0.5                                 # e3
e4       = 0.7                                 # e4
e5       = 0.9                                 # e5
M        = np.linspace(0, 2 * np.pi,W)         # Mean anomaly vector


for i in range(W):
    E1_NR[i], ite =  newton_rhapson_method(M[i],e1,N,eps)
    E2_NR[i], ite =  newton_rhapson_method(M[i],e2,N,eps)
    E3_NR[i], ite =  newton_rhapson_method(M[i],e3,N,eps)
    E4_NR[i], ite =  newton_rhapson_method(M[i],e4,N,eps)
    E5_NR[i], ite =  newton_rhapson_method(M[i],e5,N,eps)
    E1_SM[i], ite =  secant_method(M[i],e1,N,eps)
    E2_SM[i], ite =  secant_method(M[i],e2,N,eps)
    E3_SM[i], ite =  secant_method(M[i],e3,N,eps)
    E4_SM[i], ite =  secant_method(M[i],e4,N,eps)
    E5_SM[i], ite =  secant_method(M[i],e5,N,eps)

#=======================================
# Validation 3.
#=======================================

E_NR     = np.zeros(W)                         # Roots matrix for Newton Rhapson
E_SM     = np.zeros(W)                         # Roots matrix for Secant Method
e        = np.linspace(0.001,0.999,W)            # e
M        = np.linspace(0, 2 * np.pi,W)         # Mean anomaly vector
ite_NR   = np.zeros((W,W))                     # Iterarion map
ite_SM   = np.zeros((W,W))                     # Iterarion map
for i in range(W):
    for j in range(W):
        E_NR[i], ite_NR[j,i] =  newton_rhapson_method(M[j],e[i],N,eps)
        E_SM[i], ite_SM[j,i] =  secant_method(M[j],e[i],N,eps)

print("=================================================")
print("Creating plots, it might take a few seconds.")
print("=================================================")

#=======================================
# Create plots.
#=======================================

# Plot path
output_plot1 = "NR_eccentricity.pdf"
output_plot2 = "SM_eccentricity.pdf"
output_plot3 = "NR_iterationMap.pdf"
output_plot4 = "SM_iterationMap.pdf"
# Figure specifications
fontsize=15

#=======================================
# Start first plot
#=======================================

plt.figure(1)
plt.figure(figsize = (8,8))
plt.tick_params(axis='both', which='both',length=3, width=1.0,
labelsize=15, right=True, top=True, direction='in') # For ticks in borders

# Figure labels
plt.xlabel(r"$M[rads]$", fontsize=fontsize)
plt.ylabel(r"$E[rads]$", fontsize=fontsize)

# Plot title
plt.title("Newton-Raphson Method", fontsize=fontsize)

# Plot
plt.plot(M,E1_NR,color="blue", linestyle="solid", label=r"$e_{1}=0.1$")
plt.plot(M,E2_NR,color="darkorange",linestyle="solid", label=r"$e_{2}=0.3$")
plt.plot(M,E3_NR,color="purple", linestyle="solid", label=r"$e_{3}=0.5$")
plt.plot(M,E4_NR,color="green", linestyle="solid", label=r"$e_{4}=0.7$")
plt.plot(M,E5_NR,color="red", linestyle="solid", label=r"$e_{5}=0.9$")

# Legend
plt.legend(fontsize=fontsize-2, loc='upper left')

# Save figure
plt.savefig(output_plot1,bbox_inches='tight')

#=======================================
# Start second plot
#=======================================

plt.figure(2)
plt.figure(figsize = (8,8))
plt.tick_params(axis='both', which='both',length=3, width=1.0,
labelsize=15, right=True, top=True, direction='in') # For ticks in borders

# Plot title
plt.title("Secant Method", fontsize=fontsize)

# Figure labels
plt.xlabel(r"$M[rads]$", fontsize=fontsize)
plt.ylabel(r"$E[rads]$", fontsize=fontsize)

# Plot
plt.plot(M,E1_SM,color="blue", linestyle="dashed", label=r"$e_{1}=0.1$")
plt.plot(M,E2_SM,color="darkorange",linestyle="dashed", label=r"$e_{2}=0.3$")
plt.plot(M,E3_SM,color="purple", linestyle="dashed", label=r"$e_{3}=0.5$")
plt.plot(M,E4_SM,color="green", linestyle="dashed", label=r"$e_{4}=0.7$")
plt.plot(M,E5_SM,color="red", linestyle="dashed", label=r"$e_{5}=0.9$")
# Legend
plt.legend(fontsize=fontsize-2, loc='upper left')

# Save figure
plt.savefig(output_plot2,bbox_inches='tight')

#=======================================
# Start third plot
#=======================================
plt.figure(3)
plt.figure(figsize=(8,8))
plt.tick_params(axis='both', which='both',length=3, width=1.0,
labelsize=15, right=True, top=True, direction='in') # For ticks in borders

# Figure labels
plt.xlabel(r"$eccentricity$", fontsize=fontsize)
plt.ylabel(r"$M[rads]$", fontsize=fontsize)

# Plot title
plt.title("Newton-Raphson Method", fontsize=fontsize)

# Plot
# Calculate the ranges for 'e' and 'M'
e_range = e.max() - e.min()
M_range = M.max() - M.min()

# Calculate the aspect ratio based on the ratio of data ranges
aspect_ratio = e_range / M_range

# Create the plot
plt.imshow(ite_NR, cmap='rainbow', origin='lower', extent=(e.min(), e.max(), M.min(), M.max()))

# Set the aspect ratio to be proportional to the data ranges
plt.gca().set_aspect(aspect_ratio)

# Add a colorbar
plt.colorbar()

# Save figure
plt.savefig(output_plot3,bbox_inches='tight')

#=======================================
# Start fourth plot
#=======================================
plt.figure(4)
plt.figure(figsize=(8,8))
plt.tick_params(axis='both', which='both',length=3, width=1.0,
labelsize=15, right=True, top=True, direction='in') # For ticks in borders

# Plot title
plt.title("Secant Method", fontsize=fontsize)

# Figure labels
plt.xlabel(r"$eccentricity$", fontsize=fontsize)
plt.ylabel(r"$M[rads]$", fontsize=fontsize)

# Plot

# Calculate the ranges for 'e' and 'M'
e_range = e.max() - e.min()
M_range = M.max() - M.min()

# Calculate the aspect ratio based on the ratio of data ranges
aspect_ratio = e_range / M_range

# Create the plot
plt.imshow(ite_SM, cmap='rainbow', origin='lower', extent=(e.min(), e.max(), M.min(), M.max()))

# Set the aspect ratio to be proportional to the data ranges
plt.gca().set_aspect(aspect_ratio)

# Add a colorbar
plt.colorbar()

# Save figure
plt.savefig(output_plot4,bbox_inches='tight')

plt.close(1)
plt.close(2)
plt.close(3)
plt.close(4)
print("=================================================")
print("The pogram have finished succesfully!")
print(f"You can find the results for validation 1 in: {output_file}")
print(f"You can find the plots for validation 2 in: {output_plot1} & {output_plot2}")
print(f"You can find the plots for validation 3 in: {output_plot3} & {output_plot4}")
print("=================================================")
