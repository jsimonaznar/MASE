#=======================================
# Rotation matrix function.
#
# Master in Space and Aeronautical
# Engineering.
# Astrodynamics Course, Assginment 1.
# By: Jorge Simón, Javier Sanchez
# & Iñaki Fernandez.
# Last modification: 29/10/2023
#
#=======================================

#=======================================
# Import modules
#=======================================

import numpy as np
import matplotlib.pyplot as plt

#=======================================
# Compute the rotation matrix
#=======================================

def rotational_matrix (Omega, omega, inclination):

    R = np.zeros ((3,3))
    R[0,0] = np.cos(Omega)*np.cos(omega) - np.sin(Omega)*np.cos(inclination)*np.sin(omega)
    R[0,1] = -np.cos(Omega)*np.sin(omega) - np.sin(Omega)*np.cos(inclination)*np.cos(omega)
    R[0,2] = np.sin(Omega)*np.sin(inclination)
    R[1,0] = np.sin(Omega)*np.cos(omega) + np.cos(Omega)*np.cos(inclination)*np.sin(omega)
    R[1,1] = -np.sin(omega)*np.sin(Omega) + np.cos(Omega)*np.cos(inclination)*np.cos(omega)
    R[1,2] = -np.cos(Omega)*np.sin(inclination)
    R[2,0] = np.sin(inclination)*np.sin(omega)
    R[2,1] = np.sin(inclination)*np.cos(omega)
    R[2,2] = np.cos(inclination)

    return R    

