#=======================================
#
# Kepler Equation solver using:
#  1-Newton-Rhapson Method.
#  2-Secant Mehotd
# 
# Master in Space and Aeronautical
# Engineering.
# Astrodynamics Course, Assginment 1.
# By: Jorge Simón, Javier Sanchez
# & Iñaki Fernandez.
# Last modification: 29/10/2023
#
#=======================================

#=======================================
# Import Modules
#=======================================

import numpy as np
import matplotlib.pyplot as plt

#=======================================
# Define function and derivative.
#=======================================

def kepler_eq(M, E, e):
    #===================================
    # We define the Kepler Equation
    # M is the mean anomaly.
    # e is the eccentricity.
    # E is the aimed solution.
    #===================================
    return E - e * np.sin(E) - M

def kepler_eq_dev(M, E, e):
    #===================================
    # We define the Kepler Equation 
    # derivative.
    # E is the aimed solution.
    #===================================
    return 1.0 - e * np.cos(E)

#=======================================
# Newton-Rhapson Method
#=======================================

def newton_rhapson_method(M,e,N,eps):
    #===================================
    # M is the mean anomaly.
    # e is the esccentricity.
    # N is the iteration steps
    # for N-R method.
    # eps is the accuracy of the method
    #
    # The algorithm:
    #
    # x1 = x0 - f(x0) / f'(x0)
    # Is |x1-x0| < eps?
    # YES: root x1
    # NO : x0 = x1 and repeat.
    #
    # Our functions:
    # f(E) = E - e * sin(E) - M
    # f'(E) = 1 - e * cos(E)
    #===================================

    # Initial guess
    x0 = M                               # Good initial guess.

    # Iterations for the N-R method
    for i in range(N):

        x1 = x0 - (kepler_eq(M,x0,e)) / (kepler_eq_dev(M,x0,e))

        # if for accuracy
        if np.abs(x1 - x0) < eps:
            #print("======================================")
            #print("Newton-Rhapson coverged in iteration" +" "+str(i))
            #print("======================================")
            return x1
            break
        else:
            x0 = x1
    print("=====================================")
    print("<^> WARNING: N-R DID NOT CONVERGE <^>")
    print("=====================================")

#=======================================
# Secant Method.
#=======================================
def secant_method(M, e, N, eps):
    #===================================
    # Secant method: ( stimation of the
    # derivative.
    # The algorithm:
    # 
    # x2 = x1 - (x1-x0) / (f(x1) - f(x0)) * f(x1)
    # Is |x2-x1| < eps?
    # YES: root x2
    # NO : x0 = x1 x1 = x2 and repeat.
    #===================================
    x0 = M                               # Good initial guess
    x1 = M + 0.1                         # Good initial guess
    for i in range (N):
        f0 = kepler_eq(M, x0, e)
        f1 = kepler_eq(M, x1, e)
        x2 = x1 - (x1 - x0) / (f1 - f0) * f1

        if np.abs(x2 - x1) < eps:
            #print("======================================")
            #print("Secant method coverged in iteration" +" "+str(i))
            #print("======================================")
            return x2
            break
        else:
            x0, x1 = x1, x2

    print("===============================================")
    print("<^> WARNING: SECANT METHOD DID NOT CONVERGE <^>")
    print("===============================================")

